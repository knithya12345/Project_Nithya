Node Version - 8.11.x
NPM Version - 6.1.x
Angular CLI Version - 6.0.3

Generate required files in Angular through NPM
	1. npm generate component <component name>
	2. npm generate module <module name>
	3. npm generate class <class name>
	4. ng generate module app-routing --flat --module=app