package com.project.codetest.services;

import java.util.List;

import org.springframework.stereotype.Service;

@Service
public interface ICodeCoreServices {
	public List<Object> getEmployeesData();
	
}
