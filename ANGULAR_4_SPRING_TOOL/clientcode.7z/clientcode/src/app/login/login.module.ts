import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
//import { LoginComponent } from './login.component';
//import { HttpClientModule } from '@angular/common/http';
//import { Http } from '@angular/http';

@NgModule({
  imports: [
    CommonModule/* ,
    LoginComponent,
    HttpClientModule */
  ],
  declarations: []
})
export class LoginModule { }
