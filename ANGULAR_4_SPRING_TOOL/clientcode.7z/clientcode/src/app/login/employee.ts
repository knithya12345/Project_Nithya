export interface Employee{
    id:string;
	name:string;
    email:string;
    dept:string;
	address:string;
	pincode:string;
    country:string;
    salary:string;
}